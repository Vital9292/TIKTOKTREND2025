import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Trend-related API calls
export const fetchTrends = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tiktok-data/hashtags`);
    return response.data;
  } catch (error) {
    console.error('Error fetching trends:', error);
    throw error;
  }
};

// Product-related API calls
export const fetchProducts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tiktok-data/products`);
    return response.data;
  } catch (error) {
    console.error('Error fetching products:', error);
    throw error;
  }
};

// TikTok data-related API calls
export const fetchTrendingVideos = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tiktok-data/videos`);
    return response.data;
  } catch (error) {
    console.error('Error fetching trending videos:', error);
    throw error;
  }
};

// TikTok Shop API calls
export const fetchTikTokShopProducts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tiktok-shop/products`);
    return response.data;
  } catch (error) {
    console.error('Error fetching TikTok Shop products:', error);
    throw error;
  }
};

export const fetchTikTokShopOrders = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tiktok-shop/orders`);
    return response.data;
  } catch (error) {
    console.error('Error fetching TikTok Shop orders:', error);
    throw error;
  }
};

export const fetchTikTokShopAnalytics = async (params) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tiktok-shop/analytics/sales`, { params });
    return response.data;
  } catch (error) {
    console.error('Error fetching TikTok Shop analytics:', error);
    throw error;
  }
};

export const fetchTikTokShopTrending = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tiktok-shop/trending`);
    return response.data;
  } catch (error) {
    console.error('Error fetching TikTok Shop trending products:', error);
    throw error;
  }
};

export const updateProductPrice = async (productId, price) => {
  try {
    const response = await axios.patch(`${API_BASE_URL}/tiktok-shop/products/${productId}/price`, { price });
    return response.data;
  } catch (error) {
    console.error('Error updating product price:', error);
    throw error;
  }
};

// Utility functions
export const formatNumber = (num) => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num;
};

export const formatCurrency = (num) => {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(num);
};

export const getTrendLevelColor = (level) => {
  switch (level) {
    case 'high':
      return 'error.main';
    case 'medium':
      return 'warning.main';
    case 'low':
      return 'success.main';
    default:
      return 'primary.main';
  }
};
