const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  stock: {
    type: Number,
    required: true
  },
  category: {
    type: String,
    required: true
  },
  images: {
    type: [String],
    default: []
  },
  sales_count: {
    type: Number,
    default: 0
  },
  trend_score: {
    type: Number,
    default: 0
  },
  supplier: {
    type: String,
    default: 'AliExpress'
  },
  shipping_time: {
    type: String,
    default: '7-14 days'
  },
  profit_margin: {
    type: Number,
    default: 50
  },
  created_at: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Product', ProductSchema);
