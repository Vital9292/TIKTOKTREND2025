const mongoose = require('mongoose');

const TrendSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  hashtag: {
    type: String,
    required: true
  },
  growth_rate: {
    type: Number,
    required: true
  },
  views: {
    type: Number,
    required: true
  },
  engagement_rate: {
    type: Number,
    required: true
  },
  category: {
    type: String,
    required: true
  },
  related_hashtags: {
    type: [String],
    default: []
  },
  created_at: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Trend', TrendSchema);
